package RucksackProblem;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class KnapsackProblem {
    private int capacity;
    private List<Item> availableItems;
    private Random random;

    public KnapsackProblem(int capacity, List<Item> availableItems) {
        this.capacity = capacity;
        this.availableItems = availableItems;
        this.random = new Random();
    }

    public KnapsackSolution createNewSolution() throws NoSolutionException {
        // Prüfen, ob überhaupt ein einziger Gegenstand in den Rucksack passt
        boolean canFitAtLeastOne = false;
        for (Item item : availableItems) {
            if (item.getWeight() <= capacity) {
                canFitAtLeastOne = true;
                break;
            }
        }

        // Falls kein einziger Gegenstand passt, Exception werfen
        if (!canFitAtLeastOne && !availableItems.isEmpty()) {
            throw new NoSolutionException("Kein Gegenstand passt in den Rucksack. Alle spezifizierten Gegenstände sind zu schwer.");
        }

        KnapsackSolution solution = new KnapsackSolution(capacity);

        // kopie der Gegenstände erstellen, damit Originalproblem unverändert
        List<Item> remainingItems = new ArrayList<>(availableItems);

        while (true) {
            // Filtern: Welche der verbleibenden passen rein
            List<Item> fittingItems = new ArrayList<>();
            for (Item item : remainingItems) {
                if (item.getWeight() <= solution.getRemainingCapacity()) {
                    fittingItems.add(item);
                }
            }

            // Abbruchbedingung
            if (fittingItems.isEmpty()) {
                break;
            }

            // Zufälligen Gegenstand auswählen
            int randomIndex = random.nextInt(fittingItems.size());
            Item chosenItem = fittingItems.get(randomIndex);

            // In Rucksack packen
            solution.addItem(chosenItem);

            // Aus Liste der verbleibenden, Gegenstände entfernen
            remainingItems.remove(chosenItem);
        }

        return solution;
    }
}