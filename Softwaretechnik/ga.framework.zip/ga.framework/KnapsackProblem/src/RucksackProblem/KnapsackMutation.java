package RucksackProblem;

import ga.framework.model.Solution;
import ga.framework.operators.EvolutionException;
import ga.framework.operators.EvolutionaryOperator;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class KnapsackMutation implements EvolutionaryOperator {

    @Override
    public Solution evolve(Solution solution) throws EvolutionException {
       KnapsackSolution original = (KnapsackSolution) solution;

       KnapsackSolution mutation = new KnapsackSolution(original);

       Random r = new Random();

       if(r.nextBoolean()){
           int rIndex = random.nextInt(mutation);
       }
       return mutation;
    }
