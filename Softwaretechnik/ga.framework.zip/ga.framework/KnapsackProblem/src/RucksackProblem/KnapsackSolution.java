package RucksackProblem;

import ga.framework.model.*;

import java.util.ArrayList;
import java.util.List;

public class KnapsackSolution extends Solution {
    private List<Item> itemsInside;
    private int currentWeight;
    private int capacity;

    public KnapsackSolution(Problem problem, int capacity) {
        super(problem);
        this.capacity = capacity;
        this.currentWeight = 0;
    }
    public List<Item> getItems() {
        this.itemsInside = new ArrayList<Item>();
        return itemsInside;
    }

    public boolean addItem(Item item) {
        if (currentWeight + item.getWeight() <= capacity) {
            itemsInside.add(item);
            currentWeight += item.getWeight();
            return true;
        }
        return false;
    }

    public int getRemainingCapacity() {
        return capacity - currentWeight;
    }

    public List<Item> getItemsInside() {
        return itemsInside;
    }

    public int getCurrentWeight() {
        return currentWeight;
    }
}