package RucksackProblem;

public class NoSolutionException extends Exception {
    public NoSolutionException(String message) {
        super(message);
    }
}