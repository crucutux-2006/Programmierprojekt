package RucksackProblem;

import ga.framework.model.Solution;
import ga.framework.operators.FitnessEvaluator;

import java.util.Comparator;
import java.util.List;

public class KnapsackFitnessEvaluator implements FitnessEvaluator {

    @Override
    public void evaluate(List<Solution> population) {
        for (Solution s : population) {
            KnapsackSolution populationSolution = (KnapsackSolution) s;

            int fitness = populationSolution.getItems().stream()
                    .mapToInt(item -> item.getWeight())
                    .sum();
            populationSolution.setFitness(fitness);
        }
    }
}