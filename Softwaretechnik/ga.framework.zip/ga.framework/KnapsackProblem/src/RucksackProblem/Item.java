package RucksackProblem;

public class Item {

    private String name;
    private int weight;
    private int value;

    public Item(String name, int weight) {
        this.name = name;
        this.weight = weight;
    }

    public String getName() {
        return name;
    }

    public int getWeight() {
        return weight;
    }

    public int getValue() {return value;}
}