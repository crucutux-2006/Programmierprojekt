package Aufgabe1;

import ga.framework.model.Solution;
import ga.framework.operators.EvolutionException;
import ga.framework.operators.EvolutionaryOperator;

public class Evolution implements EvolutionaryOperator {

    Solution solution;

    public Evolution(Solution solution) {
        this.solution = solution;
    }

    public Solution evolve(Solution solution) throws EvolutionException{
        if(solution == null){
            throw new EvolutionException("Solution is null");
        }
        return solution;
    }
}