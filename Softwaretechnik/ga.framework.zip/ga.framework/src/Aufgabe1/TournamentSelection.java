package Aufgabe1;

public class TournamentSelection {
    
}
