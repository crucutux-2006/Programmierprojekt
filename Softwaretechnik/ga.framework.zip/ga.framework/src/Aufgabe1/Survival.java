package Aufgabe1;

import ga.framework.model.Solution;
import ga.framework.operators.SurvivalException;
import ga.framework.operators.SurvivalOperator;

import java.util.ArrayList;
import java.util.List;

public class Survival implements SurvivalOperator {

    Survival survival;

    public Survival(Survival survival){
        this.survival = survival;
    }

    public List<Solution> selectPopulation(List<Solution> candidates, int populationSize)throws SurvivalException {

        if(candidates.isEmpty()){
            throw new SurvivalException("No candidates found");
        }
        else if (populationSize >= candidates.size()){
            return candidates;
        }

        List<Solution> newPopulation = new ArrayList<>();

        for(int i = 0; i < populationSize; i++){
            Solution newCandidates = candidates.get(i);
            newPopulation.add(newCandidates);
        }

        return newPopulation;
    }
}

