package Aufgabe1;

import ga.framework.model.Solution;
import ga.framework.operators.SurvivalException;
import ga.framework.operators.SurvivalOperator;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class TopKSurvival implements SurvivalOperator {

    public int k;
    public Random random = new Random();

    public  TopKSurvival(int k) {
        this.k = k;
    }

    @Override
    public List<Solution> selectPopulation(List<Solution> candidates, int populationSize) throws SurvivalException {
        if(this.k > populationSize) {
            throw  new SurvivalException(" K darf nicht größer als die Populationsgröße sein!");
        }
        List<Solution> newl = new ArrayList<>();

        List<Solution> SortList = sortCandi(candidates);

        for (int i = 0; i < this.k; i++) {
            newl.add(SortList.get(i));
        }
        getRandom(newl, SortList, populationSize);

        return newl;
    }

    private List<Solution> sortCandi (List<Solution> candidates) {
        List<Solution> neue = new ArrayList<>(candidates);

        neue.sort((s1, s2 ) -> Double.compare(s2.getFitness(), s1.getFitness()));

        return neue;
    }

    private void getRandom (List<Solution> newl, List<Solution> newby, int zielgroesse) {

        while (newl.size() < zielgroesse) {

            int zufall = random.nextInt(newby.size());

            newl.add(newby.get(zufall));
        }
    }






}
