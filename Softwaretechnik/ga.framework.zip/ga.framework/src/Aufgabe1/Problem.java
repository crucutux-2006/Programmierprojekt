package Aufgabe1;

import ga.framework.model.NoSolutionException;
import ga.framework.model.Solution;

public class Problem implements ga.framework.model.Problem {

    Problem problem;

    public Problem  (Problem problem) {
        problem= this.problem;
    }

    public Problem getProblem() {
        return problem;
    }

    public void setProblem(Problem problem) {
        this.problem = problem;
    }

    public Solution createNewSolution() throws NoSolutionException{
       return null;
    }

}
