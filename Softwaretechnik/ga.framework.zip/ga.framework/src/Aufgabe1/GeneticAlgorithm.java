package Aufgabe1;

import ga.framework.model.NoSolutionException;
import ga.framework.model.Solution;
import ga.framework.operators.EvolutionException;
import ga.framework.operators.EvolutionaryOperator;
import ga.framework.operators.SelectionOperator;
import ga.framework.operators.SurvivalException;

import java.util.ArrayList;
import java.util.List;

public class GeneticAlgorithm {

    Problem problem;
    int populationSize;
    List<EvolutionaryOperator> operators;
    Fitness fitness;
    Survival survival;
    int evolutions;


    public GeneticAlgorithm(Problem problem, List<EvolutionaryOperator> operators , int populationSize, Fitness fitness, Survival survival, int evolutions) {
        this.problem = problem;
        this.operators = operators;
        this.populationSize = populationSize;
        this.fitness = fitness;
        this.survival = survival;
        this.evolutions = evolutions;
    }

    public List<Solution> runOptimization() throws NoSolutionException, EvolutionException, SurvivalException {


        List<Solution> population = new ArrayList<Solution>(populationSize);
       for(int i = 0; i < populationSize; i++) {
           try {
            Solution newSolution =problem.createNewSolution();
            population.add(newSolution);
           } catch (NoSolutionException e) {
               throw new NoSolutionException("No solution found.");
           }

           Solution bestSolution = fitness.evaluate(population);
       }


       for (int i = 0; i < evolutions; i++) {

           int Zufall = (int) (Math.random()* operators.size());
           EvolutionaryOperator operator = operators.get(Zufall);

           List<Solution> newGen = new ArrayList<>();

           for(Solution solution : population) {
               try {
                 Solution offspring = operator.evolve(solution);
                   newGen.add(offspring);
               } catch (EvolutionException e) {
                   throw new EvolutionException(" No evolution possible .");
               }
           }


           population.addAll(newGen);



               fitness.evaluate(population);

        try{
            population= survival.selectPopulation(population,populationSize);
        } catch (SurvivalException e) {
            throw new SurvivalException("Survival exception.");
        }

       }




return population; //Terminierungskriterium
    }

}
