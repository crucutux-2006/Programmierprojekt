package RucksackProblem;

import ga.framework.model.Solution;
import ga.framework.operators.FitnessEvaluator;

import java.util.Comparator;
import java.util.List;

public class KnapsackFitnessEvaluator implements FitnessEvaluator {

    @Override
    public Solution evaluate(List<Solution> population) {
        // 1. Fitness für jede Lösung in der Population berechnen und setzen
        population.forEach(solution -> {
            if (solution instanceof KnapsackSolution) {
                KnapsackSolution knapsackSolution = (KnapsackSolution) solution;
                int fitness = calculateFitness(knapsackSolution);
                knapsackSolution.setFitness(fitness);
            }
        });

        // 2. Beste Lösung (höchster Fitnesswert) mittels Stream suchen und zurückgeben
        return population.stream()
                .max(Comparator.comparingDouble(Solution::getFitness))
                .orElse(null);
    }


    private int calculateFitness(KnapsackSolution solution) {
        return solution.getItemsInside().stream()
                .mapToInt(item -> item.getValue()) // Lambda-Ausdruck (oder item -> item.getWeight(), falls nach Gewicht gewertet wird)
                .sum();
    }
}