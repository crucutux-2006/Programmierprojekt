package RucksackProblem;

import ga.framework.model.Solution;
import ga.framework.operators.EvolutionException;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class KnapsackMutation {
       private final KnapsackProblem problem;
       private final Random random;

    public KnapsackMutation(KnapsackProblem problem, Random random) {
        this.problem = problem;
        this.random = random;
    }

    public Solution mutate(Solution original) throws EvolutionException {
        if(!(original instanceof KnapsackSolution)){
            throw new EvolutionException("Ungültiger Solution-Typ");
        }
       KnapsackSolution mutatedCopy = new KnapsackSolution((KnapsackSolution) original);

        return null;
    }
}
