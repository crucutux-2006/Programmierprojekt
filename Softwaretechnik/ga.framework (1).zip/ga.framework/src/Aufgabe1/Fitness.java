package Aufgabe1;

import ga.framework.model.Solution;
import ga.framework.operators.FitnessEvaluator;

import java.util.List;

public class Fitness implements FitnessEvaluator {


    public Solution evaluate(List<Solution> population) {

        Solution best= null;
        for (Solution solution : population) {
            solution.setFitness();

        if ( best== null || solution.getFitness() < best.getFitness()) {
            best = solution;
        }
        }
        return best;
    }

}
