package de.clean.similarity;

/**
 * Levenshtein String similarity
 */
public class Levenshtein implements StringSimilarity {
    public Levenshtein() {
    }

    /**
     * Calculates Levenshtein String similarity for x and y
     * @param x
     * @param y
     * @return Similarity score in range [0,1]
     */
    @Override
    public double compare(String x, String y) {
        double res = 0;
        int m = x.length();
        int n = y.length();

        // BEGIN SOLUTION
        int [][] arr = new int[m+1][n+1];
        char [] arrX = x.toCharArray();
        char [] arrY = y.toCharArray();

        //Basisfälle:
        for (int i = 0; i <= m; i++) {
            arr[i][0] = i;
        }

        for (int j = 0; j <= n; j++) {
            arr[0][j] = j;
        }
        //Berechnung
        for(int i = 1; i <= m; i++) {
            for(int j = 1; j <= n; j++) {
                if(arrX[i-1] == arrY[j-1]) {
                    arr[i][j] = arr[i-1][j-1];
                }
                else {
                    int insert = arr[i][j-1];
                    int delete = arr[i-1][j];
                    int replace = arr[i-1][j-1];
                    arr[i][j] = Math.min(Math.min(insert, delete), replace)+1;
                }
            }
        }

        res =  1 - ((double) arr[m][n] / Math.max(m,n)); //levenshtein similarity
        // END SOLUTION
        return res;
    }
}
