
Distributed Systems - 24.08.2026

Prof. Dr. Boris Koldehofe, Mehran Salmani, Ahmad Baghdadi

---

# Programmierpraktikum 2026

## One Day Lab - CampusBite

In this lab, you work on **CampusBite**, a food-delivery system on campus.  
The current design is built on a synchronous RESTful client-server model using HTTP.  
You will analyze the current design, identify its limitations, and then improve it with a Publish/Subscribe model using Apache Kafka.

**Time:** One day  
**Language for Part 2:** Java (`java/`)  
**What you need to show:** Short notes, diagrams, and working code as described later.  
**Passing grade:** There are 40 points; you need to achieve at least 25 points.   

---

## Part 0: Analyzing the problem (6 points)

### Workflow 

The customer (student) uses an app/webpage to interact with the Order Service.  
When a customer places an order, the Order Service interacts with the Notification and Restaurant Services.  
The Notification Service sends a confirmation to the customer using SMS. The Restaurant Service shows the order on the kitchen screen.
The following figure shows the current system architecture: 

![Current Architecture](current_design.png)

**Note:**  
The Order Service sends the following data to the other two services:  
`{ orderId, studentID, restaurantId, items[], totalCost, timestamp }`  

The product team now wants to add an **Analytics Service** that reacts whenever an order is created as follows:

| Service | What it should do |
|---|---|
| **Notification Service** | SMS to the customer |
| **Restaurant Service** | Shows the order on the kitchen screen |
| **Analytics Service** | Counts orders per hour for a dashboard monitor |

#

### Questions  

**Question 1: &nbsp; (1 points)**  
What are the changes needed for adding the Analytics Service to the current architecture?   
Update the sketch.

> Hint: Customer only interacts with Order service. It is the responsibility of the Order service to inform other services. Keep the current workflow sequence as is, and only add the new steps for the new service.

**Question 2: &nbsp; (1 point)**  
Consider that the Restaurant Service is **down/crashed** at the moment.  
Explain the issues that affect the system in this case.  

**Question 3: &nbsp; (2 point)**  
Consider some customers **phone** the restaurant to place an order (they do not have internet access to interact with the Order Service).  
The restaurant staff enters the order, and the Restaurant Service (instead of the Order Service) creates the order (with the customer's phone number on the order).

These types of orders still need the same follow-ups as app/webpage orders: e.g., Notification Service (SMS to the given number) and Analytics Service (count the order). The Order Service already does that for app/webpage orders. Now, the Restaurant Service must do the same. Note that the Restaurant Service cannot contact the Order Service; only real students can use the app to contact it.

Argue what happens in the system? Sketch the new design after this requirement.

> Hint: Duplicate Functionality!

**Question 4: &nbsp; (2 points)**  
Assume that the Notification Service is too slow during the rush hours.  
To speed up the process, you run **two instances** of this service.   
Each new order should be handled by **exactly one** of the instances (they share the work).

What components need to change to reflect this new requirement? How would they handle it?

---

## Part 1: A better model: Publish/Subscribe (6 points)

Publish/Subscribe (Pub/Sub) is a widely deployed paradigm to support
decoupled communication between data producers (publishers) and consumers
(subscribers).   
Apache Kafka is a well-known Pub/Sub system designed for reliability, high throughput, and scalability.
Kafka structure is shown in the following figure: 

![Pubsub Image](Kafka_pub-sub.png)

**Note:**  
Before answering the questions in this part, you need to get familiar with Kafka concepts by checking the following links:   
https://kafka.apache.org/43/getting-started/introduction/

---

### Questions

**Question 1: &nbsp; (3 points)**   
Explain how the Pub/Sub model using Kafka can solve at least three of the problems in Part 0.  

> Hint: benefit from different Kafka concepts; for example, Kafka Consumer Group.

**Question 2: &nbsp; (3 points)**  
Sketch the new system design for CampusBite using Kafka components, showing how the services interact in such a system.  

---

## Part 2: Complete CampusBite with Kafka (28 points)

**Apache Kafka** implements the Pub/Sub model from Part 1.  
The **`java/`** folder contains a **partial** CampusBite setup: Docker Compose, Kafka, and one package **per service**.  
Some services only publish (produce), some only subscribe (consume), and **Restaurant Service does both**.  

Topic creation and the Kafka produce/consume logic are missing — you fill them in, then build and run the project.

In each incomplete spot, write code **only** between these markers. Do the tasks step by step, then try out your code (checkout **Build and run** below). At the end of each step, bring down the Kafka cluster with `docker compose down`, then rebuild for the next step.

```java
// """Add your code after this"""
// your code here
// """End your code before this"""
```

Use `KafkaIO.publish(...)` and `KafkaIO.makeConsumer(...)` and other helper functions from `campusbite.common.KafkaIO`. Constants are in `campusbite.common.Settings`.

#### Step 1 — Create the topic `orders.placed` (4 points)

Complete `java/src/main/java/campusbite/CreateTopics.java` so it creates **`orders.placed`** topic (2 partitions, replication factor 1).

The docker-compose service `create-topics` runs this class once at startup (after Kafka is healthy). Other services wait until it finishes successfully.

#### Step 2 — Produce/consume to/from the topic `orders.placed` (12 points)

Complete the marker blocks for **`orders.placed` only**:

1. `java/src/main/java/campusbite/orderservice/OrderServiceApp.java` — publish `OrderPlaced`
2. `java/src/main/java/campusbite/restaurantservice/RestaurantApiApp.java` — publish `OrderPlaced` (for orders by telephone) **and** consume `orders.placed` to show orders on the kitchen screen (one class; consumer runs on a background thread)
3. `java/src/main/java/campusbite/notificationservice/NotificationApp.java` — consume `orders.placed`; `handleEvent` prints the “received” SMS

After the project runs, check that:

- An order by customer app/telephone produces a kitchen screen and an SMS log message.
- Two notification instances **share** work within their consumer group (no double SMS for the same order)
- Other services (different consumer groups) still see **every** `OrderPlaced`

#### Step 3 — New feature: the topic `orders.accepted` (12 points)

Restaurants accept an order right after it appears on the kitchen screen, and the customer should get a second SMS.

Extend your code:

1. `CreateTopics.java` — also create **`orders.accepted`** (same partition/replication settings)
2. `RestaurantApiApp.java` — in the same consumer loop, after `showOnKitchenScreen`, publish `OrderAccepted` to `orders.accepted` (use `buildAcceptedEvent`)
3. `NotificationApp.java` — consume **both** `orders.placed` and `orders.accepted` (`handleEvent` already prints “received” vs “accepted”)

Then recreate/restart the affected services and verify an SMS **accepted** appears after the kitchen screen / received SMS.

### Build and run

From `2026/java/`:

```bash
# First start (build images + start all services)
# create-topics runs Step 1; then the apps start
docker compose up --build

# Stop
docker compose down

```

### Try the flow

```bash
# App order
curl -s -X POST http://localhost:8000/orders \
  -H 'Content-Type: application/json' \
  -d '{"student_id":"s1","restaurant_id":"mensa-nord","items":["pasta"],"total_eur":6.5,"phone":"+49111"}'

# Counter / phone-in order (second publisher of OrderPlaced)
curl -s -X POST http://localhost:8001/counter-orders \
  -H 'Content-Type: application/json' \
  -d '{"phone":"+49222","restaurant_id":"mensa-nord","items":["soup"],"total_eur":3.0}'
```

**After Step 2:** restaurant `KITCHEN SCREEN new order`, notification `Order … received`.  
**After Step 3:** also notification `Order … accepted by restaurant`.
