package campusbite.restaurantservice;

import campusbite.common.KafkaIO;
import campusbite.common.Settings;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.javalin.Javalin;
import io.javalin.json.JavalinJackson;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.consumer.KafkaConsumer;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Restaurant Service — counter/phone-in HTTP API + Kafka consumer in one process.
 *
 * <pre>POST /counter-orders -&gt; OrderPlaced (source=counter)</pre>
 * Background consumer: OrderPlaced -&gt; kitchen screen (-&gt; OrderAccepted in Step 3).
 */
public final class RestaurantApiApp {

    private static final KafkaProducer<String, String> PRODUCER = KafkaIO.makeProducer();

    public static void main(String[] args) {
        Thread consumerThread = new Thread(RestaurantApiApp::runConsumerLoop, "restaurant-consumer");
        consumerThread.setDaemon(true);
        consumerThread.start();

        Javalin app = Javalin.create(config -> config.jsonMapper(new JavalinJackson())).start(8001);

        app.get("/health", ctx -> ctx.json(Map.of("status", "ok")));

        app.post("/counter-orders", ctx -> {
            CounterOrderIn body = ctx.bodyAsClass(CounterOrderIn.class);
            String orderId = UUID.randomUUID().toString();

            Map<String, Object> event = KafkaIO.newEvent();
            event.put("event_type", "OrderPlaced");
            event.put("order_id", orderId);
            event.put("student_id", null);
            event.put("restaurant_id", body.restaurantId);
            event.put("items", body.items != null ? body.items : List.of());
            event.put("total_eur", body.totalEur);
            event.put("phone", body.phone);
            event.put("source", "counter");
            event.put("created_at", Instant.now().toString());

            // """Add your code after this"""

            // Step 2: Publish `event` to Settings.TOPIC_ORDERS_PLACED (key=orderId).
            // Hint: Use KafkaIO.publish
            KafkaIO.publish(PRODUCER, Settings.TOPIC_ORDERS_PLACED, event,orderId);

            // """End your code before this"""

            ctx.status(201).json(Map.of(
                    "order_id", orderId,
                    "status", "created",
                    "source", "counter"
            ));
        });
    }

    private static void runConsumerLoop() {
        // """Add your code after this"""

        // Step 2: Consume Settings.TOPIC_ORDERS_PLACED with groupId=Settings.GROUP_RESTAURANT.
        //         For each message, call showOnKitchenScreen(...).
        try (KafkaConsumer<String, String> consumer = KafkaIO.makeConsumer(
                List.of(Settings.TOPIC_ORDERS_PLACED),
                Settings.GROUP_RESTAURANT
        )) {
            while (true) {
                var records = consumer.poll(java.time.Duration.ofMillis(300));
                for (var record : records) {
                    Map<String, Object> event = KafkaIO.readEvent(record.value());

                    showOnKitchenScreen(event);

        // Step 3: After showing on the kitchen screen, also publish OrderAccepted
        //         to Settings.TOPIC_ORDERS_ACCEPTED (use buildAcceptedEvent; key=order_id).

        // Hint: KafkaIO.makeConsumer
        //       Then consume the topic in a non-terminating loop using the returned consumer.
        //       Use buildAcceptedEvent to build the OrderAccepted event from the consumed OrderPlaced event.
        //       Use KafkaIO.publish to publish the OrderAccepted event.

        // """End your code before this"""
        
    }

    static void showOnKitchenScreen(Map<String, Object> event) {
        System.out.printf(
                "[restaurant] KITCHEN SCREEN new order %s restaurant=%s items=%s%n",
                event.get("order_id"),
                event.get("restaurant_id"),
                event.get("items")
        );
    }

    /** Builds the OrderAccepted event from a consumed OrderPlaced event (complete). */
    static Map<String, Object> buildAcceptedEvent(Map<String, Object> placed) {
        Map<String, Object> accepted = KafkaIO.newEvent();
        accepted.put("event_type", "OrderAccepted");
        accepted.put("order_id", placed.get("order_id"));
        accepted.put("restaurant_id", placed.get("restaurant_id"));
        accepted.put("phone", placed.get("phone"));
        accepted.put("eta_minutes", 25);
        accepted.put("accepted_at", Instant.now().toString());
        return accepted;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class CounterOrderIn {
        public String phone;

        @JsonProperty("restaurant_id")
        public String restaurantId;

        public List<String> items;

        @JsonProperty("total_eur")
        public double totalEur;
    }
}
