package campusbite.notificationservice;

import campusbite.common.KafkaIO;
import campusbite.common.Settings;
import org.apache.kafka.clients.consumer.KafkaConsumer;


import java.util.Map;
import java.util.List;

/**
 * Notification Service — SMS(prints to stdout).
 *
 * Step 2: subscribe to orders.placed (order received).
 * Step 3: also subscribe to orders.accepted (restaurant accepted).
 * Uses consumer group GROUP_NOTIFICATION so multiple replicas share work.
 */
public final class NotificationApp {

    private static final String INSTANCE =
            System.getenv().getOrDefault("INSTANCE_NAME", "notification-1");

    public static void main(String[] args) throws Exception {
        // """Add your code after this"""

        // Step 2: Consume Settings.TOPIC_ORDERS_PLACED with groupId=Settings.GROUP_NOTIFICATION (use KafkaIO.makeConsumer).
        //  Then, in a non-terminating loop, poll events from the returned consumer. For each event, call handleEvent(KafkaIO.readEvent(event.value())).

        try (KafkaConsumer<String, String> consumer = KafkaIO.makeConsumer(
                List.of(Settings.TOPIC_ORDERS_PLACED),
                Settings.GROUP_NOTIFICATION
        )) {
            while (true) {
                var records = consumer.poll(java.time.Duration.ofMillis(100));
                for (var record : records) {
                    Map<String, Object> event = KafkaIO.readEvent(record.value());
                    handleEvent(event);

        // Step 3: Consume BOTH TOPIC_ORDERS_PLACED and TOPIC_ORDERS_ACCEPTED with the same group.
        
        // """End your code before this"""

    }

    static void handleEvent(Map<String, Object> event) {
        Object orderId = event.get("order_id");
        Object phoneObj = event.get("phone");
        String phone = phoneObj == null ? "unknown" : String.valueOf(phoneObj);
        String type = String.valueOf(event.get("event_type"));

        if ("OrderAccepted".equals(type)) {
            Object eta = event.get("eta_minutes");
            System.out.printf(
                    "[%s] SMS to %s: Order %s accepted by restaurant, ETA %s min%n",
                    INSTANCE, phone, orderId, eta
            );
        } else {
            System.out.printf("[%s] SMS to %s: Order %s received%n", INSTANCE, phone, orderId);
        }
    }
}
