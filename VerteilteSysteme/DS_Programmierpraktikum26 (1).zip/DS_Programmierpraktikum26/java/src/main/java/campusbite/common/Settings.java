package campusbite.common;

/**
 * CampusBite — shared settings (complete; do not change unless asked).
 */
public final class Settings {

    public static final String KAFKA_BOOTSTRAP_SERVERS =
            env("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092");

    public static final String TOPIC_ORDERS_PLACED = "orders.placed";
    public static final String TOPIC_ORDERS_ACCEPTED = "orders.accepted";

    public static final String GROUP_NOTIFICATION = "notification-service";
    public static final String GROUP_RESTAURANT = "restaurant-service";

    private Settings() {
    }

    private static String env(String key, String defaultValue) {
        String value = System.getenv(key);
        return (value == null || value.isBlank()) ? defaultValue : value;
    }
}
