#!/bin/sh
set -e
cd /app
# Rebuild so bind-mounted source edits are picked up (same idea as Python bind mounts).
mvn -q -B -DskipTests package
cp -f target/campusbite-1.0.0.jar /app/app.jar
exec java $JAVA_OPTS -cp /app/app.jar "$MAIN_CLASS"
