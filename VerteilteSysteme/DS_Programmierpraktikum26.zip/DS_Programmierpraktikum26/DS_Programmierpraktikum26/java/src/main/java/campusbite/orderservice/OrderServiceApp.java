package campusbite.orderservice;

import campusbite.common.KafkaIO;
import campusbite.common.Settings;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.javalin.Javalin;
import io.javalin.json.JavalinJackson;
import org.apache.kafka.clients.producer.KafkaProducer;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Order Service — HTTP API for app-placed orders; publishes to orders.placed.

 */
public final class OrderServiceApp {

    private static final KafkaProducer<String, String> PRODUCER = KafkaIO.makeProducer();

    public static void main(String[] args) {
        Javalin app = Javalin.create(config -> config.jsonMapper(new JavalinJackson())).start(8000);

        app.get("/health", ctx -> ctx.json(Map.of("status", "ok")));

        app.post("/orders", ctx -> {
            OrderIn body = ctx.bodyAsClass(OrderIn.class);
            String orderId = UUID.randomUUID().toString();

            Map<String, Object> event = KafkaIO.newEvent();
            event.put("event_type", "OrderPlaced");
            event.put("order_id", orderId);
            event.put("student_id", body.studentId);
            event.put("restaurant_id", body.restaurantId);
            event.put("items", body.items != null ? body.items : List.of());
            event.put("total_eur", body.totalEur);
            event.put("phone", body.phone);
            event.put("source", "app");
            event.put("created_at", Instant.now().toString());

            // """Add your code after this"""
            // Step 2: Publish event to Settings.TOPIC_ORDERS_PLACED (use orderId as message key).
            KafkaIO.publish(PRODUCER, Settings.TOPIC_ORDERS_PLACED, event, orderId);
            // """End your code before this"""
            ctx.status(201).json(Map.of("order_id", orderId, "status", "created"));
        });
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class OrderIn {
        @JsonProperty("student_id")
        public String studentId;

        @JsonProperty("restaurant_id")
        public String restaurantId;

        public List<String> items;

        @JsonProperty("total_eur")
        public double totalEur;

        public String phone;
    }
}
