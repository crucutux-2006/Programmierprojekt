package campusbite.notificationservice;

import campusbite.common.KafkaIO;
import campusbite.common.Settings;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import java.time.Duration;

import java.util.Map;
import java.util.List;

/**
 * Notification Service — SMS(prints to stdout).
 *
 * Step 2: subscribe to orders.placed (order received).
 * Step 3: also subscribe to orders.accepted (restaurant accepted).
 * Uses consumer group GROUP_NOTIFICATION so multiple replicas share work.
 */
public final class NotificationApp {

    private static final String INSTANCE =
            System.getenv().getOrDefault("INSTANCE_NAME", "notification-1");

    public static void main(String[] args) throws Exception {
        // """Add your code after this"""
        List<String> topics = List.of(Settings.TOPIC_ORDERS_PLACED, Settings.TOPIC_ORDERS_ACCEPTED);
        KafkaConsumer<String, String> consumer = KafkaIO.makeConsumer(topics, Settings.GROUP_NOTIFICATION);        // Step 2 & 3: Subscribe to BOTH TOPIC_ORDERS_PLACED and TOPIC_ORDERS_ACCEPTED with the same group.
        consumer.subscribe(List.of(Settings.TOPIC_ORDERS_PLACED, Settings.TOPIC_ORDERS_ACCEPTED));
        System.out.printf("[%s] NotificationApp gestartet. Warte auf Events...%n", INSTANCE);
        // Non-terminating loop (Endlosschleife zum Abfragen der Events)
        while (true) {
        // Holt aktiv neue Nachrichten vom Kafka Broker ab (wartet max. 100ms)
            ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(100));
            for (ConsumerRecord<String, String> record : records) {
                if (record.value() != null) {
                    // Wandle den JSON-String / Value in eine Map um
                    Map<String, Object> eventData = KafkaIO.readEvent(record.value());

                    // Verarbeite das Event mit der vorgegebenen Methode
                    handleEvent(eventData);
                }
            }
        }
        // """End your code before this"""

    }

    static void handleEvent(Map<String, Object> event) {
        Object orderId = event.get("order_id");
        Object phoneObj = event.get("phone");
        String phone = phoneObj == null ? "unknown" : String.valueOf(phoneObj);
        String type = String.valueOf(event.get("event_type"));

        if ("OrderAccepted".equals(type)) {
            Object eta = event.get("eta_minutes");
            System.out.printf(
                    "[%s] SMS to %s: Order %s accepted by restaurant, ETA %s min%n",
                    INSTANCE, phone, orderId, eta
            );
        } else {
            System.out.printf("[%s] SMS to %s: Order %s received%n", INSTANCE, phone, orderId);
        }
    }
}
