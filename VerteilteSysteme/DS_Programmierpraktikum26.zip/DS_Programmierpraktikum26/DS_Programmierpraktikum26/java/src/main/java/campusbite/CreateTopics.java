package campusbite;

import campusbite.common.Settings;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.admin.NewTopic;

import java.util.Properties;
import java.util.List;

/**
 * Create CampusBite topics (runs once at stack start via the create-topics service).
 *
 * Your job: create the required topics (see markers below).
 */
public final class CreateTopics {

    public static void main(String[] args) throws Exception {
        Properties props = new Properties();
        props.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, Settings.KAFKA_BOOTSTRAP_SERVERS);

        AdminClient admin = null;
        for (int attempt = 1; attempt <= 30; attempt++) {
            try {
                admin = AdminClient.create(props);
                admin.listTopics().names().get();
                break;
            } catch (Exception e) {
                System.out.printf("Kafka not ready, retry %d/30...%n", attempt);
                if (admin != null) {
                    admin.close();
                    admin = null;
                }
                Thread.sleep(2000);
            }
        }
        if (admin == null) {
            throw new IllegalStateException("Kafka not available");
        }

        try (AdminClient client = admin) {
            NewTopic topicPlaced = new NewTopic(Settings.TOPIC_ORDERS_PLACED, 2, (short) 1);
            NewTopic topicAccepted = new NewTopic(Settings.TOPIC_ORDERS_ACCEPTED, 2, (short) 1);

            // 2. Die Topics in einer Liste sammeln und an den Kafka-Server senden
            client.createTopics(List.of(topicPlaced, topicAccepted)).all().get();

            System.out.println("[CreateTopics] Die Topics 'orders.placed' und 'orders.accepted' wurden erfolgreich angelegt!");

            // """End your code before this"""
        }
    }
}
